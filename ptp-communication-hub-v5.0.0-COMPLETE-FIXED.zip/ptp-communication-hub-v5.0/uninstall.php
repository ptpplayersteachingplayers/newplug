<?php
/**
 * PTP Communication Hub Uninstall
 * 
 * Removes all plugin data when uninstalled
 */

// If uninstall not called from WordPress, exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

global $wpdb;

// Delete all plugin tables
$tables = array(
    $wpdb->prefix . 'ptp_parents',
    $wpdb->prefix . 'ptp_messages',
    $wpdb->prefix . 'ptp_conversations',
    $wpdb->prefix . 'ptp_campaigns',
    $wpdb->prefix . 'ptp_voice_calls',
    $wpdb->prefix . 'ptp_chat_sessions',
    $wpdb->prefix . 'ptp_chat_messages'
);

foreach ($tables as $table) {
    $wpdb->query("DROP TABLE IF EXISTS $table");
}

// Delete all plugin options
delete_option('ptp_comm_twilio_account_sid');
delete_option('ptp_comm_twilio_auth_token');
delete_option('ptp_comm_twilio_phone_number');
delete_option('ptp_comm_hubspot_api_key');
delete_option('ptp_comm_slack_webhook_url');
delete_option('ptp_comm_quiet_hours_enabled');
delete_option('ptp_comm_quiet_hours_start');
delete_option('ptp_comm_quiet_hours_end');
delete_option('ptp_comm_timezone');

// Clear any cached data
wp_cache_flush();
