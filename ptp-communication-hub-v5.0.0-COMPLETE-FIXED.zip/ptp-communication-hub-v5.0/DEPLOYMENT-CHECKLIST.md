# PTP Communication Hub v5.0 - Deployment & Validation Checklist

## 🎯 PRE-DEPLOYMENT CHECKLIST

### Server Requirements
- [ ] WordPress 5.0 or higher installed
- [ ] PHP 7.4 or higher
- [ ] MySQL 5.7 or higher / MariaDB 10.3+
- [ ] SSL certificate installed (HTTPS required for webhooks)
- [ ] WP-Cron enabled OR server cron configured
- [ ] PHP memory limit: 256MB recommended
- [ ] Max execution time: 300 seconds recommended

### Backup & Safety
- [ ] Full database backup created
- [ ] All WordPress files backed up
- [ ] Staging environment tested (if available)
- [ ] Recovery plan documented
- [ ] Downtime window scheduled (if needed)
- [ ] Staff notified of deployment

### Credentials Ready
- [ ] Twilio Account SID (Sandbox)
- [ ] Twilio Auth Token (Sandbox)
- [ ] Twilio Phone Number (Sandbox)
- [ ] Twilio Account SID (Live) - for future
- [ ] Twilio Auth Token (Live) - for future
- [ ] Twilio Phone Number (Live) - for future
- [ ] HubSpot Private App Access Token
- [ ] Slack Webhook URL (optional)

---

## 📥 INSTALLATION STEPS

### Step 1: Upload Plugin
```bash
Method 1: WordPress Admin
1. Go to Plugins → Add New → Upload Plugin
2. Choose: ptp-communication-hub-v5.0.0-COMPLETE.zip
3. Click: Install Now
4. Wait for upload to complete

Method 2: FTP/SFTP
1. Extract ZIP locally
2. Upload ptp-communication-hub-v5.0/ folder to wp-content/plugins/
3. Verify file permissions: 644 for files, 755 for directories
```

**Validation:**
- [ ] Plugin appears in Plugins list
- [ ] Version shows: 5.0.0
- [ ] No upload errors

### Step 2: Activate Plugin
```bash
1. Go to: Plugins → Installed Plugins
2. Find: PTP Communication Hub
3. Click: Activate
```

**Validation:**
- [ ] "Plugin activated" success message appears
- [ ] "PTP Comms" menu appears in admin sidebar
- [ ] Menu has 7 items: Inbox, Campaigns, Templates, Analytics, Contacts, Settings, System Log
- [ ] No PHP errors in browser console
- [ ] No PHP errors in debug.log

### Step 3: Verify Database Tables
```sql
-- Run in phpMyAdmin or MySQL command line
SHOW TABLES LIKE 'wp_ptp_%';

-- Should return 13 tables:
wp_ptp_analytics_snapshots
wp_ptp_audit_log
wp_ptp_campaigns
wp_ptp_chat_messages
wp_ptp_chat_sessions
wp_ptp_compliance_log
wp_ptp_conversations
wp_ptp_message_queue
wp_ptp_messages
wp_ptp_parents
wp_ptp_templates
wp_ptp_user_markets
wp_ptp_voice_calls
```

**Validation:**
- [ ] All 13 tables created
- [ ] No database errors in error log
- [ ] Tables have correct structure (check one or two)

### Step 4: Verify User Roles
```bash
1. Go to: Users → Add New (don't actually add)
2. Check "Role" dropdown
3. Should see:
   - PTP Communication Admin
   - PTP Communication Agent
```

**Validation:**
- [ ] Custom roles created
- [ ] Roles appear in dropdown
- [ ] Current admin user can access all menus

### Step 5: Check Default Templates
```bash
1. Go to: PTP Comms → Templates
2. Should see 5 default templates:
   - Quick Weather Update
   - 7-Day Weather Cancellation  
   - Camp Confirmation
   - Camp Reminder
   - HELP Response
```

**Validation:**
- [ ] Default templates installed
- [ ] Templates have categories
- [ ] Templates are marked as "Active"

---

## ⚙️ CONFIGURATION STEPS

### Step 1: Twilio Sandbox Configuration
```bash
1. Go to: PTP Comms → Settings
2. Twilio Configuration section
3. Select: ● Sandbox (not Live)
4. Enter Sandbox credentials:
   - Sandbox Account SID: ACxxxxxxxx (from Twilio)
   - Sandbox Auth Token: •••••••••• (from Twilio)
   - Sandbox Phone Number: +15005550006 (test number)
5. Click: Save All Settings
```

**Validation:**
- [ ] Settings saved successfully
- [ ] No credential errors
- [ ] "System Health" shows 🟢 Twilio

### Step 2: Quiet Hours Configuration
```bash
1. Still in Settings
2. Compliance & Quiet Hours section
3. Check: ☑ Enforce quiet hours
4. Set times:
   - Quiet Period: 21:00 to 08:00
   - Timezone: America/New_York (or your zone)
5. Set signature:
   - "Reply STOP to opt out. Msg&data rates apply."
6. Check: ☑ Automatically add signature
```

**Validation:**
- [ ] Quiet hours enabled
- [ ] Times make sense for your market
- [ ] Signature will appear on messages

### Step 3: Message Queue Configuration
```bash
1. Still in Settings
2. Message Queue section
3. Check: ☑ Enable message queue
4. Set batch size: 50 (default)
```

**Validation:**
- [ ] Queue enabled
- [ ] Batch size reasonable
- [ ] "System Health" shows 🟢 Queue

### Step 4: HubSpot Integration (Optional)
```bash
1. Still in Settings
2. HubSpot Integration section
3. Enter: Private App Access Token
4. Check: ☑ Auto-Sync
5. Click: Save All Settings
```

**Validation:**
- [ ] Token saved
- [ ] "System Health" shows 🟢 HubSpot
- [ ] OR shows "Disconnected" if not configured (OK)

### Step 5: Slack Notifications (Optional)
```bash
1. Still in Settings
2. Slack Integration section
3. Enter: Webhook URL
4. Check: ☑ Send notifications
5. Click: Save All Settings
```

**Validation:**
- [ ] Webhook saved
- [ ] Test notification received in Slack (if configured)

---

## 🧪 TESTING PHASE

### Test 1: Send Test SMS
```bash
1. Go to: PTP Comms → Inbox
2. Click: New Conversation (top right)
3. Enter verified phone number (must be verified in Twilio sandbox)
4. Type message: "Testing PTP Communication Hub v5.0"
5. Click: Send
```

**Validation:**
- [ ] Message sent successfully
- [ ] No errors in browser console
- [ ] Conversation appears in inbox
- [ ] Message shows "Sent" status
- [ ] Signature appended automatically
- [ ] Audit log entry created

### Test 2: Receive Inbound SMS
```bash
1. From verified phone, text your Twilio number
2. Message: "Hello from parent"
3. Check inbox
```

**Validation:**
- [ ] Message appears in inbox within 10 seconds
- [ ] Conversation status updates
- [ ] Message thread displays correctly
- [ ] Parent contact created/updated
- [ ] Unread badge appears
- [ ] Audit log entry created

### Test 3: Template Insertion
```bash
1. Open a conversation
2. Click template dropdown
3. Select "Quick Weather Update"
4. Verify merge tags populated
5. Edit if needed
6. Send
```

**Validation:**
- [ ] Template loaded in composer
- [ ] Merge tags replaced ({{first_name}} etc)
- [ ] Message sent successfully
- [ ] Template usage count incremented

### Test 4: Shortcode Usage
```bash
1. Open conversation
2. In composer, type: /weather
3. Press Tab or Enter
```

**Validation:**
- [ ] Template auto-fills
- [ ] Shortcode recognized
- [ ] Quick entry works

### Test 5: Campaign Creation (DRY RUN)
```bash
1. Go to: PTP Comms → Campaigns
2. Click: New Campaign
3. Step 1 - Choose audience: Test segment (1-2 contacts)
4. Step 2 - Write message: "Test campaign"
5. Step 3 - Schedule: Send Immediately
6. Step 4 - Review
7. Click: Launch Campaign
```

**Validation:**
- [ ] Wizard flows smoothly
- [ ] Recipient count accurate
- [ ] Preview looks correct
- [ ] Campaign created
- [ ] Messages queued
- [ ] Messages sent (check after 1 minute)
- [ ] Campaign stats update

### Test 6: Contact Import
```bash
1. Create test CSV:
   first_name,last_name,email,phone,child_names,markets
   John,Test,john@test.com,+15555551234,Tommy,Steelyard
   
2. Go to: PTP Comms → Contacts
3. Click: Import CSV
4. Upload file
5. Click: Import
```

**Validation:**
- [ ] Import successful
- [ ] Contacts appear in list
- [ ] Fields mapped correctly
- [ ] No duplicate errors

### Test 7: Analytics Dashboard
```bash
1. Go to: PTP Comms → Analytics
2. Check widgets load:
   - Messages Sent
   - Messages Received
   - Response Rate
   - New Conversations
3. Check chart renders
```

**Validation:**
- [ ] All stats display
- [ ] Chart.js loads
- [ ] Data reflects test messages
- [ ] Date filter works

### Test 8: Audit Log
```bash
1. Go to: PTP Comms → System Log
2. Verify recent actions appear:
   - Settings updates
   - Messages sent
   - Campaign created
   - Contacts imported
```

**Validation:**
- [ ] All test actions logged
- [ ] User attribution correct
- [ ] Timestamps accurate
- [ ] Payload data visible

### Test 9: Environment Switching
```bash
1. Go to: Settings
2. Switch from Sandbox to Live
3. Verify warning/confirmation
4. Don't save (stay in Sandbox for now)
```

**Validation:**
- [ ] Radio buttons work
- [ ] Credential fields toggle
- [ ] Can switch back

### Test 10: User Role Assignment
```bash
1. Go to: Users → Add New
2. Create test user: agent@test.com
3. Assign role: PTP Communication Agent
4. Save
5. Log in as agent (different browser)
6. Verify limited access:
   - Can see: Inbox, Templates, Contacts
   - Cannot see: Settings, System Log
```

**Validation:**
- [ ] Agent role restricts access
- [ ] Agent can respond to messages
- [ ] Agent cannot change settings

---

## 🔒 SECURITY VALIDATION

### Check 1: Direct File Access
```bash
Open in browser:
https://yoursite.com/wp-content/plugins/ptp-communication-hub-v5.0/assets/css/ptp-commhub-admin.css

Should show: CSS content (OK) or "403 Forbidden" (better)
```

**Validation:**
- [ ] Files not directly browseable (or protected by index.php)

### Check 2: Webhook Security
```bash
Try accessing:
https://yoursite.com/wp-json/ptp-comm/v1/webhook/twilio

Without proper POST data, should return error or empty response.
```

**Validation:**
- [ ] Webhooks don't expose sensitive data
- [ ] Invalid requests rejected

### Check 3: Capability Checks
```bash
As agent user, try:
https://yoursite.com/wp-admin/admin.php?page=ptp-commhub-settings

Should redirect or show "Insufficient permissions"
```

**Validation:**
- [ ] Agents blocked from admin pages
- [ ] Capability checks working

### Check 4: SQL Injection Prevention
```bash
In inbox search, try:
' OR 1=1 --

Should return no results or safe results, not database error.
```

**Validation:**
- [ ] Prepared statements used
- [ ] No SQL injection possible

### Check 5: Nonce Verification
```bash
Browser console → Network tab
Send message
Check POST request for _wpnonce parameter
```

**Validation:**
- [ ] Nonces present on forms
- [ ] CSRF protection active

---

## 📊 PERFORMANCE VALIDATION

### Check 1: Page Load Times
```bash
Use browser DevTools → Network tab
Measure load time for:
- Inbox page
- Campaigns page
- Analytics page

Should be < 2 seconds on decent hosting
```

**Validation:**
- [ ] Inbox loads quickly
- [ ] No excessive database queries
- [ ] Assets load efficiently

### Check 2: Database Query Count
```bash
Install Query Monitor plugin (temporary)
Check queries on:
- Inbox page (should be < 50 queries)
- Analytics page (should be < 30 queries)
```

**Validation:**
- [ ] Query count reasonable
- [ ] No N+1 query problems
- [ ] Slow queries identified (if any)

### Check 3: Memory Usage
```bash
Check PHP error log for memory warnings
Enable: ini_set('memory_limit', '256M'); if needed
```

**Validation:**
- [ ] No memory limit errors
- [ ] Plugin works within limits

---

## 🔧 WEBHOOK CONFIGURATION

### Twilio SMS Webhook
```bash
1. Login to Twilio Console
2. Phone Numbers → Your Number → Messaging
3. Set webhook:
   URL: https://yoursite.com/wp-json/ptp-comm/v1/webhook/twilio
   Method: POST
   Content-Type: application/x-www-form-urlencoded
4. Save
```

**Validation:**
- [ ] Webhook URL correct (with HTTPS)
- [ ] Method set to POST
- [ ] Twilio can reach your server
- [ ] Test inbound SMS works

### Twilio Voice Webhook
```bash
1. Same phone number → Voice & Fax
2. A CALL COMES IN:
   URL: https://yoursite.com/wp-json/ptp-comm/v1/webhook/voice
   Method: POST
3. Save
```

**Validation:**
- [ ] Voice webhook configured
- [ ] Test call triggers IVR

---

## 📈 MONITORING SETUP

### Daily Checks
- [ ] Check System Health indicators in inbox sidebar
- [ ] Review audit log for errors
- [ ] Check message queue status
- [ ] Verify HubSpot sync working (if enabled)

### Weekly Checks
- [ ] Review analytics dashboard
- [ ] Check opt-out rate (should be < 2%)
- [ ] Review template usage stats
- [ ] Check for failed campaigns

### Monthly Checks
- [ ] Export contacts for backup
- [ ] Review database size/growth
- [ ] Check Twilio usage vs budget
- [ ] Update A2P 10DLC registration (if needed)

---

## 🎓 STAFF TRAINING CHECKLIST

### For All Users
- [ ] Login to WordPress admin
- [ ] Navigate to PTP Comms menu
- [ ] Understand inbox layout
- [ ] Know how to view conversations
- [ ] Know how to reply to messages
- [ ] Understand template system

### For Agents
- [ ] Assign PTP Communication Agent role
- [ ] Train on template shortcuts (/weather, etc)
- [ ] Train on conversation status updates
- [ ] Show how to use filters
- [ ] Explain quiet hours enforcement

### For Managers
- [ ] Assign PTP Communication Admin role
- [ ] Train on campaign builder
- [ ] Show analytics dashboard
- [ ] Explain contact management
- [ ] Train on CSV import/export
- [ ] Show template creation

### For Admins
- [ ] Full settings walkthrough
- [ ] Environment switching explanation
- [ ] Audit log review process
- [ ] User role management
- [ ] Webhook configuration
- [ ] Troubleshooting basics

---

## 🚨 GO-LIVE CHECKLIST

### Before Switching to Live
- [ ] All tests passed in Sandbox
- [ ] Staff trained and comfortable
- [ ] Twilio A2P 10DLC approved
- [ ] Live Twilio credentials ready
- [ ] Backup of database taken
- [ ] Go-live time scheduled
- [ ] Stakeholders notified

### Switch to Live
```bash
1. Go to: Settings → Twilio Configuration
2. Select: ● Live
3. Enter production credentials:
   - Live Account SID
   - Live Auth Token
   - Live Phone Number
4. Verify all settings correct
5. Click: Save All Settings
6. Test with ONE real parent first
7. Monitor for errors
8. If OK, proceed with normal use
```

**Validation:**
- [ ] Live mode activated
- [ ] Test message sent successfully
- [ ] Received message processed
- [ ] No errors
- [ ] System Health all green

### Post-Launch (First 24 Hours)
- [ ] Monitor inbox continuously
- [ ] Check System Health hourly
- [ ] Review audit log for errors
- [ ] Verify HubSpot sync working
- [ ] Check Slack notifications (if enabled)
- [ ] Track first campaign performance
- [ ] Respond to any parent issues quickly

### Post-Launch (First Week)
- [ ] Daily analytics review
- [ ] Check opt-out rate
- [ ] Review response times
- [ ] Gather staff feedback
- [ ] Optimize templates based on usage
- [ ] Adjust quiet hours if needed
- [ ] Review Twilio costs

---

## ✅ SUCCESS CRITERIA

### Technical
- ✅ All 13 database tables created
- ✅ Plugin activated without errors
- ✅ Custom roles working
- ✅ Webhooks receiving data
- ✅ Messages sending reliably
- ✅ Queue processing correctly
- ✅ Audit log tracking actions
- ✅ Analytics displaying data

### User Experience
- ✅ Staff can navigate interface
- ✅ Message composition is intuitive
- ✅ Templates speed up responses
- ✅ Campaigns easy to create
- ✅ Analytics provide insights
- ✅ Contact management efficient

### Business Impact
- ✅ Parents receiving timely communication
- ✅ Response rate improved (baseline + 10%)
- ✅ Staff efficiency increased
- ✅ Opt-out rate acceptable (< 2%)
- ✅ Compliance maintained
- ✅ HubSpot data synced

---

## 🎉 DEPLOYMENT COMPLETE!

If you've checked all boxes above, your PTP Communication Hub v5.0 is:

✅ **Installed** - Plugin active and configured  
✅ **Tested** - All features validated  
✅ **Secure** - Security checks passed  
✅ **Monitored** - Tracking in place  
✅ **Trained** - Staff ready to use  
✅ **Live** - Ready for production  

**Congratulations! You've successfully deployed enterprise-grade communication infrastructure for PTP Soccer Camps!** ⚽✨

---

## 📞 Support Contacts

**Technical Issues:**
- WordPress debug.log
- PHP error_log
- Browser console
- Twilio console logs

**Twilio Support:**
- Console: https://console.twilio.com
- Support: https://support.twilio.com
- Status: https://status.twilio.com

**Plugin Documentation:**
- README.md in plugin folder
- ASSEMBLY-GUIDE.md for architecture
- COMPLETE-PLUGIN-INSTRUCTIONS.md for deployment

---

**Version:** 5.0.0 Enterprise Edition  
**Last Updated:** November 19, 2025  
**Status:** Production Ready ✅
