# Migration Guide: v4.0 → v5.0 Enterprise

## 🎯 Overview

This guide helps you migrate from PTP Communication Hub v4.0 to v5.0 Enterprise Edition.

---

## 📊 What's Changed

### Code Size
- **v4.0**: 52KB (1,320 lines)
- **v5.0**: 251KB (6,575 lines)
- **Growth**: 5x larger with enterprise features

### Database Tables
- **v4.0**: 9 tables
- **v5.0**: 13 tables
- **New tables**:
  - `wp_ptp_audit_log` - Action tracking
  - `wp_ptp_user_markets` - Access control
  - `wp_ptp_analytics_snapshots` - Daily metrics
  - Updated `wp_ptp_conversations` with more fields

### Features Added

| Feature | v4.0 | v5.0 |
|---------|------|------|
| **UI Design** | Basic WordPress | PTP-branded enterprise |
| **Inbox** | Raw message list | Threaded conversations |
| **Campaigns** | Simple table | 4-step wizard |
| **Analytics** | None | Dashboard with charts |
| **Templates** | Basic | Categories + shortcodes |
| **Settings** | Single screen | Organized panels |
| **Environment** | Live only | Live + Sandbox |
| **Audit Log** | None | Complete tracking |
| **User Roles** | Admin only | Custom admin/agent roles |
| **Market Scoping** | Tags | User assignments |

---

## 🔄 Migration Strategies

### Strategy 1: Clean Install (Recommended)

**Best for:**
- Small datasets (< 500 contacts)
- Willing to reconfigure
- Want fresh start

**Steps:**
1. Export v4 contacts to CSV
2. Document current settings (screenshot everything)
3. Deactivate v4.0
4. Delete v4.0 (or rename folder)
5. Install v5.0
6. Configure from scratch
7. Import contacts via CSV
8. Test thoroughly

**Pros:**
- ✅ Clean database
- ✅ No conflicts
- ✅ Latest schema

**Cons:**
- ❌ Loses message history
- ❌ Requires reconfiguration
- ❌ Downtime required

### Strategy 2: Upgrade In Place

**Best for:**
- Large datasets (500+ contacts)
- Must preserve history
- Can't afford downtime

**Steps:**
1. **Backup everything first!**
2. Export database backup
3. Keep v4.0 activated
4. Upload v5.0 to plugins folder (rename to avoid conflict)
5. Deactivate v4.0
6. Activate v5.0
7. Run manual table updates (see below)
8. Verify data migrated
9. Test functionality
10. Delete v4.0

**Pros:**
- ✅ Preserves message history
- ✅ Keeps contact data
- ✅ Minimal downtime

**Cons:**
- ❌ More complex
- ❌ May need SQL updates
- ❌ Testing required

### Strategy 3: Parallel Running

**Best for:**
- Enterprise deployments
- Zero-downtime requirement
- Can run both temporarily

**Steps:**
1. Install v5.0 on staging site
2. Sync data from production to staging
3. Test v5.0 thoroughly on staging
4. When ready, switch DNS/traffic to staging
5. Make staging the new production
6. Keep old site as backup for 30 days

**Pros:**
- ✅ Zero downtime
- ✅ Full testing
- ✅ Easy rollback

**Cons:**
- ❌ Requires staging site
- ❌ More resources needed
- ❌ Data sync complexity

---

## 🗄️ Database Migration

### New Tables (v5.0)

These tables will be created automatically:

```sql
-- Audit log for compliance
CREATE TABLE wp_ptp_audit_log (
    id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    user_id bigint(20) unsigned NOT NULL,
    action varchar(50) NOT NULL,
    entity_type varchar(50),
    entity_id bigint(20) unsigned,
    payload longtext,
    ip_address varchar(45),
    created_at datetime DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY user_id (user_id),
    KEY action (action),
    KEY created_at (created_at)
);

-- Market access control
CREATE TABLE wp_ptp_user_markets (
    id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    user_id bigint(20) unsigned NOT NULL,
    market varchar(100) NOT NULL,
    created_at datetime DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY user_market (user_id, market)
);

-- Daily analytics snapshots
CREATE TABLE wp_ptp_analytics_snapshots (
    id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    metric_date date NOT NULL,
    messages_sent int(11) DEFAULT 0,
    messages_received int(11) DEFAULT 0,
    conversations_new int(11) DEFAULT 0,
    optouts int(11) DEFAULT 0,
    response_rate decimal(5,2) DEFAULT 0.00,
    market varchar(100),
    created_at datetime DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY date_market (metric_date, market)
);
```

### Updated Tables (v5.0)

If upgrading from v4, run these ALTER statements:

```sql
-- Add consent fields to parents
ALTER TABLE wp_ptp_parents 
ADD COLUMN consent_status varchar(20) DEFAULT 'unknown' AFTER opted_out,
ADD COLUMN consent_date datetime NULL AFTER consent_status,
ADD COLUMN last_contacted_at datetime NULL AFTER consent_date;

-- Add conversation threading fields
ALTER TABLE wp_ptp_conversations
ADD COLUMN channel varchar(20) DEFAULT 'sms' AFTER last_message_at,
ADD COLUMN priority varchar(20) DEFAULT 'normal' AFTER unread_count,
ADD COLUMN assigned_user_id bigint(20) unsigned NULL AFTER priority,
ADD COLUMN last_message_direction varchar(20) NULL AFTER last_message_at,
ADD COLUMN market varchar(100) NULL AFTER assigned_user_id,
ADD COLUMN owner_user_id bigint(20) unsigned NULL AFTER assigned_user_id;

-- Add conversation_id to messages
ALTER TABLE wp_ptp_messages
ADD COLUMN conversation_id bigint(20) unsigned NULL AFTER parent_id,
ADD COLUMN channel varchar(20) DEFAULT 'sms' AFTER message_type,
ADD COLUMN sent_by_user_id bigint(20) unsigned NULL AFTER error_message;

-- Update templates table
ALTER TABLE wp_ptp_templates
ADD COLUMN category varchar(50) NULL AFTER name,
ADD COLUMN shortcode varchar(50) NULL AFTER content,
ADD COLUMN channel varchar(20) DEFAULT 'sms' AFTER shortcode,
ADD COLUMN usage_count int(11) DEFAULT 0 AFTER is_active;

-- Add campaign tracking
ALTER TABLE wp_ptp_campaigns
ADD COLUMN delivered_count int(11) DEFAULT 0 AFTER sent_count,
ADD COLUMN failed_count int(11) DEFAULT 0 AFTER delivered_count,
ADD COLUMN reply_count int(11) DEFAULT 0 AFTER failed_count,
ADD COLUMN optout_count int(11) DEFAULT 0 AFTER reply_count;

-- Add queue priorities
ALTER TABLE wp_ptp_message_queue
ADD COLUMN priority int(11) DEFAULT 5 AFTER max_attempts,
ADD COLUMN campaign_id bigint(20) unsigned NULL AFTER priority;
```

### Data Migration Scripts

```sql
-- Migrate consent status from opted_out flag
UPDATE wp_ptp_parents 
SET consent_status = CASE 
    WHEN opted_out = 1 THEN 'opt_out'
    ELSE 'opt_in'
END
WHERE consent_status = 'unknown';

-- Link messages to conversations
UPDATE wp_ptp_messages m
JOIN wp_ptp_conversations c ON c.parent_id = m.parent_id
SET m.conversation_id = c.id
WHERE m.conversation_id IS NULL
ORDER BY m.created_at ASC;

-- Set message channel from message_type
UPDATE wp_ptp_messages 
SET channel = CASE 
    WHEN message_type = 'sms' THEN 'sms'
    WHEN message_type = 'voice' THEN 'voice'
    ELSE 'sms'
END
WHERE channel IS NULL;

-- Initialize last_contacted_at
UPDATE wp_ptp_parents p
JOIN (
    SELECT parent_id, MAX(sent_at) as last_sent
    FROM wp_ptp_messages
    WHERE direction = 'outbound'
    GROUP BY parent_id
) m ON m.parent_id = p.id
SET p.last_contacted_at = m.last_sent
WHERE p.last_contacted_at IS NULL;
```

---

## ⚙️ Settings Migration

### Export v4 Settings

Document these before migration:

```php
// Twilio
get_option('ptp_comm_twilio_account_sid');
get_option('ptp_comm_twilio_auth_token');
get_option('ptp_comm_twilio_phone_number');

// HubSpot
get_option('ptp_comm_hubspot_api_key');

// Quiet Hours
get_option('ptp_comm_quiet_hours_enabled');
get_option('ptp_comm_quiet_hours_start');
get_option('ptp_comm_quiet_hours_end');
get_option('ptp_comm_timezone');
```

### Import to v5 Settings

v5 has these **new** settings:

```php
// Environment switching (NEW)
update_option('ptp_comm_twilio_environment', 'live'); // or 'sandbox'

// Sandbox credentials (NEW)
update_option('ptp_comm_twilio_sandbox_sid', '');
update_option('ptp_comm_twilio_sandbox_token', '');
update_option('ptp_comm_twilio_sandbox_phone', '');

// Slack integration (NEW)
update_option('ptp_comm_slack_webhook_url', '');
update_option('ptp_comm_slack_notifications_enabled', '1');

// Message queue (NEW)
update_option('ptp_comm_queue_enabled', '1');
update_option('ptp_comm_queue_batch_size', 50);

// Signature (NEW)
update_option('ptp_comm_default_signature', 'Reply STOP to opt out.');
update_option('ptp_comm_signature_enabled', '1');

// Business hours (NEW)
update_option('ptp_comm_business_hours_start', 9);
update_option('ptp_comm_business_hours_end', 18);
update_option('ptp_comm_operator_phone', '');
update_option('ptp_comm_support_phone', '');

// A2P 10DLC (NEW)
update_option('ptp_comm_a2p_status', 'pending');
update_option('ptp_comm_brand_id', '');
update_option('ptp_comm_campaign_id', '');
```

---

## 👥 User Role Migration

### v4.0 Roles
- Only WordPress admin could access

### v5.0 Roles
- **PTP Communication Admin** - Full access
- **PTP Communication Agent** - Limited access

### Migration Steps

```sql
-- Assign admin role to all current WP admins
INSERT INTO wp_usermeta (user_id, meta_key, meta_value)
SELECT ID, 'wp_capabilities', 'a:1:{s:21:"ptp_commhub_admin";b:1;}'
FROM wp_users
WHERE ID IN (
    SELECT user_id FROM wp_usermeta 
    WHERE meta_key = 'wp_capabilities' 
    AND meta_value LIKE '%administrator%'
);

-- Create agent users for your team
-- Do this manually via Users → Add New → Role: PTP Communication Agent
```

---

## 📝 Template Migration

### v4 Templates
- Basic text storage
- No categories
- No shortcodes

### v5 Templates
- Organized by category
- Shortcode support
- Usage tracking

### Migration Script

```sql
-- Add categories to existing templates
UPDATE wp_ptp_templates
SET category = CASE
    WHEN name LIKE '%weather%' THEN 'Weather'
    WHEN name LIKE '%confirm%' THEN 'Confirmation'
    WHEN name LIKE '%remind%' THEN 'Reminder'
    WHEN name LIKE '%help%' THEN 'Support'
    ELSE 'Other'
END
WHERE category IS NULL;

-- Add shortcodes to common templates
UPDATE wp_ptp_templates
SET shortcode = '/weather'
WHERE name LIKE '%weather%' AND shortcode IS NULL
LIMIT 1;

UPDATE wp_ptp_templates
SET shortcode = '/7day'
WHERE name LIKE '%7-day%' AND shortcode IS NULL
LIMIT 1;
```

---

## 🎨 UI Changes for Users

### What Staff Will Notice

**Inbox:**
- ❌ Old: Flat list of messages
- ✅ New: Threaded conversations
- ✅ New: Filters sidebar
- ✅ New: Contact info panel
- ✅ New: Status indicators

**Campaigns:**
- ❌ Old: Single form
- ✅ New: 4-step wizard
- ✅ New: Audience segments
- ✅ New: Preview & review
- ✅ New: Campaign analytics

**Templates:**
- ❌ Old: Simple list
- ✅ New: Organized by category
- ✅ New: Shortcode quick access
- ✅ New: Usage statistics

**New Features:**
- ✅ Analytics Dashboard
- ✅ Audit Log (admins)
- ✅ Environment switching
- ✅ Market scoping

### Training Requirements

**Time needed:**
- Basic users: 15 minutes
- Managers: 30 minutes
- Admins: 45 minutes

**Key concepts:**
- Conversation-based inbox
- Template shortcuts
- Campaign wizard flow
- Analytics interpretation

---

## 🧪 Testing After Migration

### Critical Tests

1. **Send Test SMS**
   - [ ] Message sends
   - [ ] Appears in inbox
   - [ ] Signature appended

2. **Receive Test SMS**
   - [ ] Inbound processed
   - [ ] Conversation updated
   - [ ] Notification sent

3. **Template Usage**
   - [ ] Templates load
   - [ ] Merge tags work
   - [ ] Shortcodes work

4. **Campaign Creation**
   - [ ] Wizard flows
   - [ ] Sends messages
   - [ ] Stats update

5. **Analytics Display**
   - [ ] Dashboard loads
   - [ ] Charts render
   - [ ] Data accurate

6. **User Permissions**
   - [ ] Admins: full access
   - [ ] Agents: limited access

7. **Historical Data**
   - [ ] Old messages visible
   - [ ] Contact info preserved
   - [ ] No data loss

---

## 🚨 Rollback Plan

If migration fails:

### Immediate Rollback

```bash
1. Deactivate v5.0
2. Restore v4.0 from backup
3. Restore database from backup
4. Activate v4.0
5. Test basic functionality
6. Document what went wrong
```

### Partial Rollback

```bash
1. Keep v5.0 installed
2. Restore only affected tables
3. Run v4 → v5 migration again
4. Investigate specific issue
5. Fix and retry
```

---

## 📊 Success Metrics

After migration is complete, track:

**Week 1:**
- [ ] Zero critical errors
- [ ] All staff can login
- [ ] Messages sending/receiving
- [ ] Campaigns functioning

**Week 2:**
- [ ] Response rate maintained or improved
- [ ] Staff comfortable with new UI
- [ ] No data loss reported
- [ ] Analytics providing value

**Month 1:**
- [ ] Opt-out rate stable (< 2%)
- [ ] Template usage increasing
- [ ] Campaign creation up
- [ ] Staff satisfaction high

---

## 🎯 Optimization Post-Migration

### Immediate (Week 1)
- [ ] Create 5-10 key templates
- [ ] Assign user roles properly
- [ ] Configure all integrations
- [ ] Train all staff

### Short-term (Month 1)
- [ ] Review template usage stats
- [ ] Optimize quiet hours
- [ ] Adjust campaign timing
- [ ] Set up daily monitoring

### Long-term (Quarter 1)
- [ ] Analyze response rates
- [ ] Refine audience segments
- [ ] Create advanced campaigns
- [ ] Export analytics for reporting

---

## 💡 Pro Tips

### For Smooth Migration

1. **Start Small**
   - Test with 10-20 contacts first
   - Run parallel for one week
   - Get feedback before full rollout

2. **Communicate**
   - Warn staff of changes
   - Provide training materials
   - Be available for questions

3. **Monitor Closely**
   - Check System Health daily
   - Review Audit Log
   - Track error rates

4. **Document Everything**
   - Screenshot v4 settings
   - Export all data
   - Keep notes of issues

5. **Have Backup Plan**
   - Keep v4.0 files for 30 days
   - Maintain database backups
   - Know rollback procedure

---

## ✅ Migration Complete Checklist

- [ ] v5.0 installed and activated
- [ ] All 13 tables created
- [ ] Historical data migrated
- [ ] Settings configured
- [ ] Integrations connected
- [ ] Users assigned roles
- [ ] Templates categorized
- [ ] Tested end-to-end
- [ ] Staff trained
- [ ] Monitoring in place
- [ ] Documentation updated
- [ ] v4.0 deactivated
- [ ] Backup verified

---

## 🎉 You've Upgraded!

**Congratulations on migrating to PTP Communication Hub v5.0 Enterprise Edition!**

You now have:
- ✅ Professional PTP-branded interface
- ✅ Powerful campaign management
- ✅ Comprehensive analytics
- ✅ Enhanced security & compliance
- ✅ Better team collaboration

**Welcome to enterprise-grade communication!** ⚽✨

---

**Need help?** Check:
- DEPLOYMENT-CHECKLIST.md for validation
- COMPLETE-PLUGIN-INSTRUCTIONS.md for features
- README.md for quick reference
