/**
 * PTP Communication Hub Admin JavaScript
 */
(function($) {
    'use strict';
    
    $(document).ready(function() {
        
        // Auto-refresh conversation view
        if ($('.ptp-conversation').length) {
            setInterval(function() {
                location.reload();
            }, 30000); // Refresh every 30 seconds
        }
        
        // Mark messages as read when viewing conversation
        $('.ptp-conversation').each(function() {
            var parentId = new URLSearchParams(window.location.search).get('parent_id');
            if (parentId) {
                $.ajax({
                    url: ptpComm.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'ptp_mark_conversation_read',
                        parent_id: parentId,
                        nonce: ptpComm.nonce
                    }
                });
            }
        });
        
        // Form validation
        $('form[name="send_message"]').on('submit', function(e) {
            var content = $(this).find('textarea[name="message_content"]').val();
            if (content.trim() === '') {
                e.preventDefault();
                alert('Please enter a message.');
                return false;
            }
        });
        
        // CSV import validation
        $('input[name="csv_file"]').on('change', function() {
            var fileName = $(this).val();
            if (fileName && !fileName.match(/\.csv$/i)) {
                alert('Please select a valid CSV file.');
                $(this).val('');
            }
        });
        
        // Confirm campaign send
        $('.ptp-send-campaign').on('click', function(e) {
            var recipientCount = $(this).data('recipients');
            if (!confirm('Send campaign to ' + recipientCount + ' recipients?')) {
                e.preventDefault();
                return false;
            }
        });
        
        // Real-time message counter
        $('textarea[name="message_content"]').on('input', function() {
            var length = $(this).val().length;
            var segments = Math.ceil(length / 160);
            var counter = $(this).siblings('.message-counter');
            
            if (counter.length === 0) {
                counter = $('<div class="message-counter"></div>');
                $(this).after(counter);
            }
            
            counter.text(length + ' characters (' + segments + ' SMS segment' + (segments !== 1 ? 's' : '') + ')');
        });
        
        // Filter parents by tag
        $('#filter-by-tag').on('change', function() {
            var tag = $(this).val();
            var rows = $('.wp-list-table tbody tr');
            
            if (tag === '') {
                rows.show();
            } else {
                rows.each(function() {
                    var tags = $(this).find('td:nth-child(4)').text();
                    if (tags.includes(tag)) {
                        $(this).show();
                    } else {
                        $(this).hide();
                    }
                });
            }
        });
        
        // Click-to-call functionality
        $('.ptp-click-to-call').on('click', function(e) {
            e.preventDefault();
            var phone = $(this).data('phone');
            var parentId = $(this).data('parent-id');
            
            if (confirm('Initiate call to ' + phone + '?')) {
                $.ajax({
                    url: ptpComm.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'ptp_initiate_call',
                        parent_id: parentId,
                        phone: phone,
                        nonce: ptpComm.nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            alert('Call initiated successfully!');
                        } else {
                            alert('Error initiating call: ' + response.data);
                        }
                    }
                });
            }
        });
        
        // Live search for parents
        $('#parent-search').on('keyup', function() {
            var search = $(this).val().toLowerCase();
            var rows = $('.wp-list-table tbody tr');
            
            rows.each(function() {
                var text = $(this).text().toLowerCase();
                if (text.includes(search)) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        });
        
        // Bulk actions
        $('#bulk-action-submit').on('click', function(e) {
            e.preventDefault();
            var action = $('#bulk-action-selector').val();
            var selected = [];
            
            $('input[name="parent[]"]:checked').each(function() {
                selected.push($(this).val());
            });
            
            if (selected.length === 0) {
                alert('Please select at least one parent.');
                return;
            }
            
            if (!confirm('Apply action to ' + selected.length + ' parent(s)?')) {
                return;
            }
            
            $.ajax({
                url: ptpComm.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'ptp_bulk_action',
                    bulk_action: action,
                    parents: selected,
                    nonce: ptpComm.nonce
                },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        alert('Error: ' + response.data);
                    }
                }
            });
        });
        
        // Toggle settings sections
        $('.ptp-settings-toggle').on('click', function() {
            $(this).next('.ptp-settings-content').slideToggle();
            $(this).toggleClass('open');
        });
        
        // Dashboard stats auto-refresh
        if ($('.ptp-comm-stats').length) {
            setInterval(function() {
                $.ajax({
                    url: ptpComm.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'ptp_get_dashboard_stats',
                        nonce: ptpComm.nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            $('.ptp-stat-box').each(function(index) {
                                $(this).find('h3').text(response.data[index]);
                            });
                        }
                    }
                });
            }, 60000); // Refresh every minute
        }
    });
    
})(jQuery);
